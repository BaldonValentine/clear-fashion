'use strict';
const MY_FAVORITE_BRANDS = [{
    'name': 'Hopaal',
    'url': 'https://hopaal.com/'
}, {
    'name': 'Loom',
    'url': 'https://www.loom.fr'
}, {
    'name': 'ADRESSE',
    'url': 'https://adresse.paris/'
}];